import 'package:flutter/material.dart'; // importação básica 
import 'splashInicio.dart'; // arquivo da tela splashInicio

void main() => runApp(MaterialApp(home: SplashInicio()));